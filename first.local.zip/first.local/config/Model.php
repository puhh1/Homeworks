<?php
require_once "config/Database.php";
		class Model
		{	public $connect;
			public function __construct()
			{
				$this->connect = new Database();
			}
			public function getALL(string $table) : array
			{
				$sql = "SELECT * FROM{$table}";
				return $this->connect->query(sql);
			}
		}
 ?>
