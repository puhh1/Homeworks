<?php

	namespace Core;

	use PDO;
	use PDOException;

	class Database
	{
		public $connect;

		function __construct()
		{
			try{
				$this->connect = new PDO('mysql:dbname=steam;host=127.0.0.1', 'root', 'root');
					$this->connect->exec ("set names utf8");
					echo "Подключение к БД произошло</br>";
			}catch (\PDOException $e){
				echo "Ошибочка следующего характера: </br> <i> {$e->getMassage()}</i>";
			}
		}
		public function query(string $sql) : array
		{
			$query = $this->query($sql);
			return $query->fetchALL(PDO::FETCH_CLASS);
		}
	}
 ?>