<?php
	declare(strict_types=1);

	require_once "vendor/autoload.php";

	use App\Controllers\UserController;
/**
	$db = new Database();
	$data = $db->commect->query("select * from users");
	$data = $data->fetchALL(PDO::FETCH_CLASS);
	echo "Номера телефонов пользователей: </br>";
	foreach ($data as $item) {
		echo "{$item->phone}</br>";
	}
**/
$users = new UserController();
$data = $users->show();
echo "Номера телефонов пользователей: </br>";
	foreach ($data as $item) {
		echo "{$item->phone}</br>";
	}
 ?>