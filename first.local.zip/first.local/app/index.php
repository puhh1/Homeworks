<?php
	declare(strict_types=1);

	require_once "config/Database.php";
/**
	$db = new Database();
	$data = $db->commect->query("select * from users");
	$data = $data->fetchALL(PDO::FETCH_CLASS);
	echo "Номера телефонов пользователей: </br>";
	foreach ($data as $item) {
		echo "{$item->phone}</br>";
	}
**/
require_once "app/controllers/UserController.php";

$users = new UserController();
$data = $users->show();
echo "Номера телефонов пользователей: </br>";
	foreach ($data as $item) {
		echo "{$item->phone}</br>";
	}
 ?>