<?php
	namespace App\Model;

	use App\Model;

	class UserModel {
		protected $table = "users";
		public function getALL() : array
		{
			$users = new Model();
			return $users->getALL($this->table);
		}
	}
 ?>