<?php
	namespace App\Controllers;

	use App\Model\UserModel;

	class UserController {
		public function show() : array
	{
		$users = new UserModel();
		return $users->getALL();
	}
}
 ?>